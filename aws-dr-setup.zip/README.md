# AWS Disaster Recovery Setup (DR)

This project provides a production-ready AWS DR solution with:
- Compute in DR (Glue, MWAA)
- Data in primary region (S3)
- Multi-Region Access Point (MRAP) for cross-region access
- Glue catalog sync and failover via Secrets Manager

## Components

- **Terraform Modules**: Deploy infrastructure (S3, Glue, MWAA, MRAP, Secrets)
- **Glue Python Script**: Copies Glue databases and tables to DR
- **MWAA DAG**: Executes based on the active region (primary or DR)
- **Failover**: Controlled by updating a secret value (`active: dr`)

## Deployment

1. Customize `variables.tf` with your account/region info.
2. Run:
   ```
   terraform init
   terraform apply
   ```
3. Upload the Glue script to DR script bucket.
4. Upload the Airflow DAG to DR DAGs bucket.
5. For failover, update secret `primary-or-dr-secret` to:
   ```json
   { "active": "dr" }
   ```

## Requirements
- Terraform
- Python 3.x with boto3
- Airflow 2.x